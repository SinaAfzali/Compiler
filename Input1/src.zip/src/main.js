import './assets/main.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { configure, defineRule } from 'vee-validate'
import { required, email } from '@vee-validate/rules'
import { localize } from '@vee-validate/i18n'
import App from './App.vue'
import router from './router'
import { registerPasswordRule } from './validation/passwordRules'
import { persianNameRule } from './validation/persianNameRules'
import { ageRangeRules } from './validation/ageRangeRules'
import dayjs from 'dayjs'
import jalaliday from 'jalaliday'

const app = createApp(App)

app.use(createPinia())
app.use(router)

// Vee-validate config
defineRule('required', required)
defineRule('email', email)
registerPasswordRule()
persianNameRule()
ageRangeRules()

configure({
  generateMessage: localize({
    fa: {
      messages: {
        required: 'پر کردن این فیلد الزامی است',
        email: 'ایمیل وارد شده معتبر نیست',
      },
    },
  }),
})

configure({
  generateMessage: localize('fa'),
})

// Calender config
dayjs.extend(jalaliday)
dayjs.calendar('jalali')

app.mount('#app')
