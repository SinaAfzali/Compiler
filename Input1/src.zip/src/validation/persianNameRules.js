import { defineRule } from 'vee-validate'

export function persianNameRule() {
  defineRule('persian_name', (value) => {
    if (!value) {
      return true
    }

    if (value.length < 3) {
      return 'نام باید حداقل 3 کاراکتر باشد.'
    } else if (value.length > 25) {
      return 'نام حداکثر میتواند 25 کاراکتر باشد.'
    }

    const pattern = /^[آ-ی\s]+$/
    return pattern.test(value) ? true : 'فقط حروف فارسی وارد کنید'
  })
}
