import { defineRule } from 'vee-validate'
const minAge = 12
const maxAge = 120

export function ageRangeRules() {
  defineRule('age_range', (value) => {
    if (!value) {
      return true
    } else if (!/\d+/.test(value)) {
      return 'فقط کاراکتر های عددی مجاز هستند.'
    } else if (Number(value) < minAge || Number(value) > maxAge) {
      return `سن باید عددی بین ${minAge} و ${maxAge} باشد.`
    }
    return true
  })
}
