import { defineRule } from 'vee-validate'

export function registerPasswordRule() {
  defineRule('password_strength', (value) => {
    if (!value) {
      return true
    }

    if (value.length < 8) {
      return 'رمز عبور باید حداقل ۸ کاراکتر باشد.'
    }

    const uppercaseRe = /[A-Z]/u
    if (!uppercaseRe.test(value)) {
      return 'رمز عبور باید حداقل یک حرف بزرگ داشته باشد.'
    }

    const symbolRe = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?`~]/u
    if (!symbolRe.test(value)) {
      return 'رمز عبور باید حداقل یک کاراکتر نماد داشته باشد.'
    }

    return true
  })
}
