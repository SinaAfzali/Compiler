<script setup>
import ReportSection from '@/components/home/ReportSection.vue'
import ActivitySidebar from '@/components/layout/ActivitySidebar.vue'
import ActivityLayout from '@/components/layout/ActivityLayout.vue'
import LeftPanelActivity from '@/components/layout/LeftPanelActivity.vue'
import CalendarJalali from '@/components/shared/CalendarJalali.vue'
import HeaderContent from '@/components/shared/HeaderContent.vue'
import ActivityCard from '@/components/shared/ActivityCard.vue'
import { ref } from 'vue'

const selectedDate = ref(null)

const leftPanelCollapsed = ref(false)

const filters = [
  {
    label: 'روزانه',
    action: () => handleFilter('daily'),
  },
  {
    label: 'هفتگی',
    action: () => handleFilter('weekly'),
  },
  {
    label: 'ماهانه',
    action: () => handleFilter('monthly'),
  },
  {
    label: 'سالانه',
    action: () => handleFilter('yearly'),
  },
]

const handleFilter = (type) => {
  console.log('Selected filter:', type)
}
</script>

<template>
  <ActivityLayout v-model:is-collapse="leftPanelCollapsed">
    <template #sidebar>
      <ActivitySidebar />
    </template>
    <template #left-panel>
      <LeftPanelActivity>
        <template #calendar>
          <CalendarJalali v-model="selectedDate" />
        </template>
      </LeftPanelActivity>
    </template>
    <div class="report">
      <div class="report__header">
        <HeaderContent :filters="filters" title="گزارش ها" />
      </div>
      <ReportSection />
    </div>
    <div class="line"></div>
    <div class="activities">
      <div class="activities__header">
        <HeaderContent title="فعالیت ها" />
      </div>
      <div
        :class="{
          activities__list: !leftPanelCollapsed,
          activities__hidenLeftList: leftPanelCollapsed,
        }"
      >
        <ActivityCard :isAnEmptyCard="true" />
        <ActivityCard :isAnEmptyCard="true" />
        <ActivityCard :isAnEmptyCard="true" />
        <ActivityCard :isAnEmptyCard="true" />
      </div>
    </div>
  </ActivityLayout>
</template>
<style lang="scss" scoped>
.report {
  width: 100%;
  &__header {
    padding: 0 48px 18px 48px;
  }
}
.activities {
  width: 100%;
  &__list {
    justify-items: center;
    grid-auto-rows: 490px;
    overflow: hidden;
    height: 490px;
    @include grid(repeat(4, 1fr), 1, 24px, center);
    @media (max-width: 1600px) {
      @include grid(repeat(3, 1fr), 1, 24px, center);
    }
    @media (max-width: 1320px) {
      @include grid(repeat(2, 1fr), 1, 24px, center);
    }
    @media (max-width: 1020px) {
      @include grid(repeat(1, 1fr), 1, 24px, center);
    }
  }
  &__hidenLeftList {
    justify-items: center;
    grid-auto-rows: 490px;
    overflow: hidden;
    height: 490px;
    @include grid(repeat(4, 1fr), 1, 24px, center);
    @media (max-width: 1360px) {
      @include grid(repeat(3, 1fr), 1, 24px, center);
    }
    @media (max-width: 1040px) {
      @include grid(repeat(2, 1fr), 1, 24px, center);
    }
    @media (max-width: 768px) {
      @include grid(repeat(1, 1fr), 1, 24px, center);
    }
  }
  &__header {
    padding: 0 48px 18px 48px;
  }
}
.line {
  width: 100%;
  height: 3px;
  background-color: white;
  margin: 40px 0;
}
</style>
