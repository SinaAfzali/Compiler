<script setup>
import BaseButton from '@/components/base/BaseButton.vue'
import AuthComponent from '@/components/auth/AuthComponent.vue'
import NameField from '@/components/shared/NameField.vue'
import AgeField from '@/components/shared/AgeField.vue'
</script>

<template>
  <AuthComponent title="اطلاعات فردی" hasArrowRight="true" :backLink="{ name: 'register' }">
    <template #top-input>
      <NameField />
    </template>
    <template #bottom-input>
      <AgeField />
    </template>
    <template #submit-button>
      <BaseButton>
        <template #content><span>تایید</span></template>
      </BaseButton>
    </template>
  </AuthComponent>
</template>

<style lang="scss" scoped></style>
