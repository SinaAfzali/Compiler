<script setup>
import BaseButton from '@/components/base/BaseButton.vue'
import AuthComponent from '@/components/auth/AuthComponent.vue'
import EmailField from '@/components/shared/EmailField.vue'
import PasswordField from '@/components/shared/PasswordField.vue'
</script>

<template>
  <AuthComponent title="ثبت نام" hasArrowRight="true" :backLink="{ name: 'login' }">
    <template #top-input>
      <EmailField />
    </template>
    <template #bottom-input>
      <PasswordField />
    </template>
    <template #submit-button>
      <BaseButton>
        <template #content><span>ثبت نام</span></template>
      </BaseButton>
    </template>
  </AuthComponent>
</template>

<style lang="scss" scoped></style>
