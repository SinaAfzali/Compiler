<script setup>
import AccountActions from '@/components/auth/LoginActions.vue'
import BaseButton from '@/components/base/BaseButton.vue'
import AuthComponent from '@/components/auth/AuthComponent.vue'
import EmailField from '@/components/shared/EmailField.vue'
import PasswordField from '@/components/shared/PasswordField.vue'
</script>

<template>
  <AuthComponent title="ورود">
    <template #top-input>
      <EmailField />
    </template>
    <template #bottom-input>
      <PasswordField />
    </template>
    <template #submit-button>
      <BaseButton>
        <template #content><span>ورود</span></template>
      </BaseButton>
    </template>
    <template #extra-content>
      <AccountActions />
    </template>
  </AuthComponent>
</template>

<style lang="scss" scoped></style>
