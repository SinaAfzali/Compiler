<script setup>
import UserIcon from '@/assets/icons/user.svg'
import BaseInput from '@/components/base/BaseInput.vue'
</script>

<template>
  <BaseInput
    name="name"
    label="نام"
    type="text"
    placeholder="نام"
    inputClass="name-input"
    wrapperClass="wrapper-class"
    :rules="{
      required: true,
      persian_name: true,
    }"
  >
    <template #icon>
      <UserIcon class="name-input__icon" />
    </template>
  </BaseInput>
</template>

<style lang="scss">
.name-input {
  min-height: 56px;

  &__icon {
    width: 24px;
    height: 24px;
    stroke: $color-primary;
  }
}
.wrapper-class {
  width: 312px !important;
}

@media (max-width: 768px) {
  .name-input {
    min-height: 48px;
  }
}
</style>
