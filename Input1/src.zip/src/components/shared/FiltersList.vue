<template>
  <section class="filter">
    <ul class="filter__list">
      <li
        v-for="(item, index) in filters"
        :key="index"
        class="filter__item"
        :class="{ 'filter__item--active': activeIndex === index }"
        @click="handleClick(item, index)"
      >
        <component v-if="item.icon" :is="item.icon" class="filter__icon" />

        <span class="filter__label">
          {{ item.label }}
        </span>
      </li>
    </ul>
  </section>
</template>

<script setup>
// Component: FilterList
import { ref } from 'vue'

const props = defineProps({
  filters: {
    type: Array,
    required: true,
    default: () => [],
  },
  initialIndex: {
    type: Number,
    default: null,
  },
})

const activeIndex = ref(props.initialIndex)

const handleClick = (item, index) => {
  activeIndex.value = index

  if (typeof item.action === 'function') {
    item.action(item)
  }
}
</script>

<style lang="scss" scoped>
.filter {
  direction: rtl;

  &__list {
    @include flex(row, flex-start, center, 8px);
    list-style: none;
    padding: 0;
    margin: 0;
  }

  &__item {
    @include flex(row, center, center, 16px);

    min-width: 55px;
    height: 28px;
    padding: 0 8px;

    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 0 4px rgba(0, 67, 101, 0.05);

    cursor: pointer;
    transition: all 0.2s ease;

    &--active {
      @include flex(row, center, center, 12px);

      min-width: 61px;
      background: #cee0fc;
      border: 1px solid $color-primary;
    }
  }

  &__icon {
    width: 14px;
    height: 14px;
    flex-shrink: 0;
  }

  &__label {
    font-size: 13px;
    color: $text-gray-dark;
    white-space: nowrap;
  }
}
</style>
