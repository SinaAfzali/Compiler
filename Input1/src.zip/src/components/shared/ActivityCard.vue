<template>
  <article class="activity-card">
    <div v-if="!isAnEmptyCard">
      <figure class="activity-card__image-wrapper">
        <img :src="image" :alt="title" class="activity-card__image" />
      </figure>

      <div class="activity-card__body">
        <header class="activity-card__header">
          <h2 class="activity-card__title">{{ title }}</h2>
          <MoreIcon class="activity-card__menu-btn" @click="$emit('menu')" />
        </header>

        <p class="activity-card__description">{{ description }}</p>

        <div class="line"></div>

        <footer class="activity-card__footer">
          <div class="activity-card__info">
            <span class="activity-card__date"><CalendarFillIcon /> {{ date }}</span>
            <span class="activity-card__time"><ClockIcon />{{ time }}</span>
          </div>
          <span class="activity-card__action-btn" @click="$emit('action')">
            {{ actionLabel }}
          </span>
        </footer>
      </div>
    </div>
    <div v-else><PlusIcon /></div>
  </article>
</template>

<script setup>
import CalendarFillIcon from '@/assets/icons/calendar-fill.svg'
import ClockIcon from '@/assets/icons/clock.svg'
import MoreIcon from '@/assets/icons/more.svg'
import PlusIcon from '@/assets/icons/Plus.svg'

defineProps({
  image: { type: String },
  title: { type: String },
  description: { type: String },
  date: { type: String },
  time: { type: String },
  actionLabel: { type: String },
  isAnEmptyCard: { type: Boolean },
})
</script>

<style lang="scss" scoped>
$radius: 24px;
$padding: 16px;
$desktop-width: 280px;
$desktop-height: 488px;
$mobile-width: 312px;
$mobile-height: 338px;

@mixin card-size($w, $h) {
  width: $w;
  height: $h;
}

.activity-card {
  @include card-size($desktop-width, $desktop-height);
  border-radius: $radius;
  background: #fff;
  overflow: hidden;
  box-sizing: border-box;
  @include flex(column, center, center);

  @media (max-width: 768px) {
    @include card-size($mobile-width, $mobile-height);
  }

  &__image-wrapper {
    width: 100%;
    height: auto;
    padding: 0 16px;
    box-sizing: border-box;
  }

  &__image {
    width: 100%;
    height: 200px;
    display: block;
    border-radius: 16px;
  }

  &__body {
    padding: $padding;
    @include flex(column, start, stretch, 12px);
    flex: 1;
  }

  &__header {
    @include flex(row, space-between, center);
  }

  &__title {
    font-size: 18px;
    font-weight: 700;
    color: #2e2f32;
    font-style: normal;
    margin: 0;
  }

  &__menu-btn {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 1.4rem;
  }

  &__description {
    font-size: 14px;
    line-height: 28px;
    font-weight: 400;
    font-style: normal;
    margin: 0;
  }

  &__footer {
    margin-top: auto;
    @include flex(column, start, start);
    width: 100%;
  }

  &__info {
    @include flex(row, start, stretch, 32px);
    font-size: 14px;
    color: #5b5e69;
    font-weight: 400;
    line-height: 28px;
    margin-bottom: 16px;
  }

  &__date {
    @include flex(row, center, center, 4px);
  }
  &__time {
    @include flex(row, center, center, 4px);
  }
  &__action-btn {
    background: #fff2f2;
    color: #e35053;
    border: none;
    cursor: pointer;
    font-size: 0.9rem;
    font-weight: 500;
    padding: 6px 12px;
    width: auto;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    flex-grow: 0;
    border-radius: 12px;
  }
}

.line {
  width: 100%;
  height: 1px;
  background-color: gray;
  opacity: 0.1;
}
</style>
