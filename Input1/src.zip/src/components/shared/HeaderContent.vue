<template>
  <header class="section-header">
    <!-- Right side: title + arrow -->
    <div class="section-header__main">
      <component
        :is="link ? (isRouter ? 'RouterLink' : 'a') : 'div'"
        :to="isRouter ? link : null"
        :href="!isRouter ? link : null"
        class="section-header__link"
      >
        <h2 class="section-header__title">
          {{ title }}
        </h2>

        <ArrowRight v-if="link" class="section-header__icon" />
      </component>
    </div>

    <!-- Left side: filters -->
    <div v-if="filters && filters.length" class="section-header__filters">
      <FilterList :filters="filters" :initialIndex="initialIndex" />
    </div>
  </header>
</template>

<script setup>
import FilterList from '@/components/shared/FiltersList.vue'
import ArrowRight from '@/assets/icons/arrow-right.svg'

defineProps({
  title: {
    type: String,
    required: true,
  },
  link: {
    type: String,
    default: null,
  },
  isRouter: {
    type: Boolean,
    default: false,
  },
  filters: {
    type: Array,
    default: () => [],
  },
  initialIndex: {
    type: Number,
    default: -1,
  },
})
</script>

<style lang="scss" scoped>
.section-header {
  @include flex(row, space-between, center);
  width: 100%;
}

/* RIGHT */
.section-header__main {
  @include flex(row, flex-end, center, 8px);
}

/* LEFT */
.section-header__filters {
  @include flex(row, flex-start, center);
}

.section-header__link {
  @include flex(row, center, center, 6px);
  text-decoration: none;
  color: inherit;
}

.section-header__title {
  font-weight: 700;
  font-size: 18px;
  line-height: 32px;
  text-align: right;
  color: #2e2f32;
}

.section-header__icon {
  width: 20px;
  height: 20px;
  color: $color-primary;
}

/* Tablet */
@media (max-width: 960px) {
  .section-header {
    @include flex(column, start, start);
    width: 100%;
  }
}
</style>
