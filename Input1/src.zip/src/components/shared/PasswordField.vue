<script setup>
import EyeIcon from '@/assets/icons/eye.svg'
import EyeSlashIcon from '@/assets/icons/eye-slash.svg'
import LockIcon from '@/assets/icons/lock.svg'
import BasePasswordInput from '../base/BasePasswordInput.vue'
</script>

<template>
  <BasePasswordInput
    name="password"
    placeholder="رمزعبور"
    label="رمزعبور"
    :rules="{ required: true, password_strength: true }"
    inputClass="password-input"
    wrapperClass="wrapper-class"
  >
    <template #lock-icon>
      <LockIcon class="password-input__lock-icon" />
    </template>

    <template #eye-icon><EyeIcon class="password-input__icon" /></template>
    <template #eye-slash-icon><EyeSlashIcon class="password-input__icon" /></template>
  </BasePasswordInput>
</template>

<style lang="scss">
.password-input {
  min-height: 56px;

  &__icon {
    width: 24px;
    height: 24px;
    fill: $color-ink;
  }
  &__lock-icon {
    width: 24px;
    height: 24px;
    stroke: $color-primary;
  }
}
.wrapper-class {
  width: 312px !important;
}

@media (max-width: 768px) {
  .password-input {
    min-height: 48px;
  }
}
</style>
