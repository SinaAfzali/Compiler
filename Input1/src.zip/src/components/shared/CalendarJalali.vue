<template>
  <div class="calendar">
    <div class="calendar__header">
      <div class="calendar__title">{{ monthName }} {{ year }}</div>
      <div class="calendar__navs">
        <ArrowRightIcon class="calendar__nav" @click="prevMonth" />
        <ArrowLeftIcon class="calendar__nav" @click="nextMonth" />
      </div>
    </div>

    <div class="calendar__weekdays">
      <div v-for="d in weekdays" :key="d" class="calendar__weekday">{{ d }}</div>
    </div>

    <div class="calendar__grid">
      <div
        v-for="(day, index) in days"
        :key="index"
        class="calendar__day"
        :class="{
          'calendar__day--empty': !day,
          'calendar__day--selected': isSelected(day),
          // 'calendar__day--past': isPast(day),
        }"
        @click="selectDay(day)"
      >
        <span v-if="day">{{ day.date() }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, computed, onMounted } from 'vue'
import dayjs from 'dayjs'
import ArrowRightIcon from '@/assets/icons/arrow-right.svg'
import ArrowLeftIcon from '@/assets/icons/arrow-left.svg'

const props = defineProps({
  modelValue: String,
})

const emit = defineEmits(['update:modelValue'])

const today = dayjs().calendar('jalali')

onMounted(() => {
  if (!props.modelValue) {
    emit('update:modelValue', today.format('YYYY-MM-DD'))
  }
})

const weekdays = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج']

const state = reactive({
  year: today.year(),
  month: today.month(),
})

const persianMonths = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
]

const monthName = computed(() => persianMonths[state.month])

// const monthName = computed(() =>
//   dayjs().year(state.year).month(state.month).calendar('jalali').format('MMMM'),
// )

const year = computed(() => dayjs().year(state.year).month(state.month).calendar('jalali').year())

const days = computed(() => {
  const start = dayjs().year(state.year).month(state.month).date(1).calendar('jalali')
  const end = start.endOf('month')

  const blanks = Array(start.day()).fill(null)

  const list = []
  for (let d = 1; d <= end.date(); d++) {
    list.push(dayjs(start).date(d).calendar('jalali'))
  }
  return [...blanks, ...list]
})

const selectDay = (day) => {
  if (!day) return
  emit('update:modelValue', day.format('YYYY-MM-DD'))
}

const isSelected = (day) => {
  if (!day || !props.modelValue) return false
  return day.format('YYYY-MM-DD') === props.modelValue
}

// const isPast = (day) => {
//   if (!day) return false
//   return day.isBefore(today, 'day')
// }

const prevMonth = () => {
  const d = dayjs()
    .year(state.year)
    .month(state.month)
    .date(1)
    .subtract(1, 'month')
    .calendar('jalali')
  state.year = d.year()
  state.month = d.month()
}

const nextMonth = () => {
  const d = dayjs().year(state.year).month(state.month).date(1).add(1, 'month').calendar('jalali')
  state.year = d.year()
  state.month = d.month()
}
</script>

<style lang="scss" scoped>
.calendar {
  width: 1005;
  font-family: 'BYekanNum', serif;
  background: #fafafa;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  padding: 20px;
  direction: rtl;
  box-sizing: border-box;

  &__header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;

    .calendar__title {
      font-weight: bold;
      font-size: 16px;
    }

    .calendar__navs {
      display: flex;
      gap: 4px;
    }
  }

  &__nav {
    width: 32px;
    height: 32px;
    cursor: pointer;
  }

  &__weekdays {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    text-align: center;
    margin-bottom: 5px;

    & > div {
      color: #999;
      font-weight: bold;
      padding: 4px 0;
    }
  }

  &__grid {
    flex: 1;
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 4px;
  }

  &__day {
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 6px;
    cursor: pointer;

    &--empty {
      pointer-events: none;
    }

    &--past {
      color: #ccc;
      pointer-events: none;
    }
    &:hover:not(.calendar__day--past) {
      background: #f0f0f0;
    }
    &--selected {
      background: #3f51b5;
      color: #fff;
    }
  }
}
</style>
