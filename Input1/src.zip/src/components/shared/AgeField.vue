<script setup>
import CalendarIcon from '@/assets/icons/calendar.svg'
import BaseInput from '@/components/base/BaseInput.vue'

const handleKeydown = (event) => {
  const char = event.key
  if (
    (!/\d/.test(char) || event.target.value.length >= 3) &&
    char !== 'Backspace' &&
    char !== 'Tab' &&
    char !== 'Enter'
  ) {
    event.preventDefault()
  }
}
</script>

<template>
  <BaseInput
    name="age"
    label="سن"
    type="number"
    placeholder="سن"
    inputClass="age-input"
    wrapperClass="wrapper-class"
    :rules="{ age_range: true }"
    @keydown="handleKeydown"
  >
    <template #icon>
      <CalendarIcon class="age-input__icon" />
    </template>
  </BaseInput>
</template>

<style lang="scss">
.age-input {
  min-height: 56px;

  &__icon {
    width: 24px;
    height: 24px;
    stroke: $color-primary;
  }
}
.wrapper-class {
  width: 312px !important;
}

@media (max-width: 768px) {
  .age-input {
    min-height: 48px;
  }
}
</style>
