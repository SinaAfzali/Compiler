<script setup>
import UserIcon from '@/assets/icons/user.svg'
import BaseInput from '@/components/base/BaseInput.vue'
</script>

<template>
  <BaseInput
    name="email"
    label="ایمیل"
    type="email"
    placeholder="ایمیل"
    inputClass="email-input"
    wrapperClass="wrapper-class"
    :rules="{ required: true, email: true }"
  >
    <template #icon>
      <UserIcon class="email-input__icon" />
    </template>
  </BaseInput>
</template>

<style lang="scss">
.email-input {
  min-height: 56px;

  &__icon {
    width: 24px;
    height: 24px;
    stroke: $color-primary;
  }
}
.wrapper-class {
  width: 312px !important;
}

@media (max-width: 768px) {
  .email-input {
    min-height: 48px;
  }
}
</style>
