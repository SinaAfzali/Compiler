<script setup>
import HomeIcon from '@/assets/icons/home.svg'
import NoteIcon from '@/assets/icons/note.svg'
import AddCircleIcon from '@/assets/icons/add-circle.svg'
import { ref } from 'vue'

const selectedIcon = ref(0)
function handleClick(value) {
  selectedIcon.value = value
}
</script>
<template>
  <div class="sidebar">
    <div class="sidebar__top">
      <HomeIcon
        @click="() => handleClick(0)"
        :class="['sidebar__icon', selectedIcon === 0 && 'sidebar__icon--selected']"
      />
      <NoteIcon
        @click="() => handleClick(1)"
        :class="['sidebar__icon', selectedIcon === 1 && 'sidebar__icon--selected']"
      />
    </div>

    <div class="sidebar__middle">
      <AddCircleIcon class="sidebar__icon2" />
    </div>
  </div>
</template>

<style lang="scss" scoped>
.sidebar {
  position: fixed;
  right: 0;
  top: 0;
  width: 80px;
  height: 100vh;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  background-color: white;

  &__top {
    margin-top: 80px;
    display: flex;
    flex-direction: column;
    gap: 20px;
    align-items: center;
  }

  &__middle {
    display: flex;
    justify-content: center;
    margin-bottom: 25vh;
  }
  &__icon {
    width: 32px;
    height: 32px;
    fill: #dadce5;

    &--selected {
      fill: #2471eb;
    }
  }

  &__icon2 {
    width: 56px;
    height: 56px;
  }
}
</style>
