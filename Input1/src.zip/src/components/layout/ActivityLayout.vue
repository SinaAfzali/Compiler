<script setup>
import SidebarLeftIcon from '@/assets/icons/sidebar-left.svg'
import SidebarRightIcon from '@/assets/icons/sidebar-right.svg'

const props = defineProps({
  isCollapse: Boolean,
})
const emit = defineEmits(['update:isCollapse'])

function toggleCollapse() {
  emit('update:isCollapse', !props.isCollapse)
}
</script>

<template>
  <aside class="layout__left-panel" :class="{ 'layout__left-panel--hiden': isCollapse }">
    <SidebarLeftIcon v-if="!isCollapse" @click="toggleCollapse" class="layout__icon" />
    <SidebarRightIcon v-else @click="toggleCollapse" class="layout__icon" />
    <div :class="{ hidden: isCollapse }">
      <slot name="left-panel"></slot>
    </div>
  </aside>

  <aside class="layout__sidebar">
    <slot name="sidebar"></slot>
  </aside>
  <div class="layout" :class="{ 'layout--hidenLeft': isCollapse }">
    <main class="layout__content" :class="{ 'layout__content--hiddenLeft': isCollapse }">
      <slot />
    </main>
  </div>
</template>

<style lang="scss" scoped>
.layout {
  @include flex(row);
  width: 100%;
  box-sizing: border-box;
  padding: 40px 0;
  padding-left: max(23%, 340px);
  padding-right: 80px;

  &--hidenLeft {
    padding-left: 32px;
  }

  &__icon {
    z-index: 100;
    fill: gray;
    width: 24px;
    height: 24px;
    cursor: w-resize;
  }
  &__left-panel {
    width: 23%;
    min-width: 340px;
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
    background: #f9f9f9;
    padding: 8px;
    border-right: 1px solid #ddd;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;

    &--hiden {
      width: 32px;
      min-width: 2px;
      padding: 4px 4px 0 0;
      border: none;
      background-color: white;
    }
  }

  &__sidebar {
    width: 80px;
    position: fixed;
    top: 0;
    right: 0;
    height: 100vh;
    background: #f1f1f1;
    padding: 20px;
    border-left: 1px solid #ddd;
    box-sizing: border-box;
  }

  &__content {
    width: calc(100% - max(23%, 340px) - 80px);
    box-sizing: border-box;
    flex: 1;
  }
}

.hidden {
  display: none;
}
</style>
