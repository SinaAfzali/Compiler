<script setup>
import Avatar from '@/assets/icons/Avatar.svg'
import NotificationIcon from '@/assets/icons/notification-bing.svg'
</script>
<template>
  <aside class="left-panel">
    <div class="left-panel__header">
      <Avatar />
      <div class="left-panel__info">
        <div class="left-panel__user">
          <div class="left-panel__user__name">بهنام وهانی</div>
          <div class="left-panel__user__event">بدون رویداد</div>
        </div>
        <NotificationIcon />
      </div>
    </div>

    <!-- Calendar -->
    <div class="left-panel__calendar">
      <slot name="calendar"></slot>
    </div>

    <!-- Today's Cards -->
    <div class="left-panel__cards">
      <div class="left-panel__card">فعالیت ۱</div>
      <div class="left-panel__card">فعالیت ۲</div>
    </div>
  </aside>
</template>

<style lang="scss" scoped>
.left-panel {
  width: max(23%, 340px);
  position: fixed;
  top: 0;
  left: 0;
  height: 100vh;
  background: white;
  padding: 40px;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;

  &__header {
    display: flex;
    align-items: center;
    margin-bottom: 48px;
    padding-left: 5px;
    padding-right: 5px;
  }

  &__avatar {
    width: 50px;
    height: 50px;
    background: #ccc;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
  }

  &__info {
    flex: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-right: 8px;
  }

  &__user {
    font-weight: bold;
    font-size: 18px;

    &__name {
      font-weight: 600;
      font-style: semi-bold;
      font-size: 16px;
      line-height: 28px;
      letter-spacing: 0%;
      color: #2e2f32;
      text-align: right;
    }

    &__event {
      font-weight: 400;
      font-style: normal;
      font-size: 14px;
      line-height: 28px;
      letter-spacing: 0%;
      color: #2e2f32;
      text-align: right;
    }
  }

  &__calendar {
    margin-bottom: 20px;
    flex-shrink: 0;
    margin-bottom: 64px;
  }

  &__cards {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  &__card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 10px;
    min-height: 80px;
  }
}
</style>
