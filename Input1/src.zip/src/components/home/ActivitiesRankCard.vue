<template>
  <div
    :class="[
      'activities-card',
      activities.length === 0 ? 'activities-card--empty-state' : 'activities-card--not-empty',
    ]"
  >
    <p v-if="activities.length !== 0" class="activities-card__title">{{ title }}</p>
    <div v-if="activities.length !== 0" class="activities-card__list">
      <div v-for="(item, index) in activities" :key="index" class="activities-card__item">
        <span class="activities-card__name">{{ item.name }}</span>
        <div
          class="activities-card__line-wrapper"
          :style="{
            width: calcLineWidth(item.count) + '%',
          }"
        >
          <div
            class="activities-card__line"
            :style="{
              background: lineColors[index],
            }"
          ></div>
        </div>
        <span class="activities-card__count">{{ item.count }}</span>
      </div>
    </div>
    <div v-if="activities.length === 0" class="activities-card__empty">
      <h3 class="activities-card__title">بیشترین ها</h3>
      <p class="activities-card__subtitle">اولین فعالیت خودت رو بساز.</p>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  title: {
    type: String,
    default: 'بیشترین ها',
  },
  activities: {
    type: Array,
    default: () => [],
  },
})
const lineColors = ['#4AD66D', '#FFBF00', '#F7953B']
function calcLineWidth(count) {
  const max = Math.max(...props.activities.map((a) => a.count)) || 1
  return (count / max) * 100
}
</script>

<style lang="scss" scoped>
.activities-card {
  width: 100%;
  box-sizing: border-box;
  min-height: 100%;
  background: white;
  border-radius: 16px;
  padding: 20px;

  &--not-empty {
    @include flex(column, start, center, 16px);
  }
  &--empty-state {
    @include flex(column, center, center, 6px);
  }

  &__title {
    font-weight: 700;
    font-size: 18px;
    color: $dark-gray;
    margin: 0;
  }

  &__subtitle {
    font-weight: 400;
    font-size: 16px;
    color: $light-gray;
    margin-top: 4px;
  }
  &__empty {
    width: 100%;
    @include flex(column, center, center);
    flex: 1;
  }

  &__list {
    @include flex(column, start, stretch, 8px);
    width: 100%;
  }

  &__item {
    @include flex(row, start, start, 12px);
    align-items: center;
    direction: rtl;
    min-height: 34px;
  }

  &__name {
    font-weight: 400;
    font-size: 16px;
    color: $dark-gray;
  }

  &__line-wrapper {
    width: 100%;
    background: #eee;
    border-radius: 8px;
    height: 8px;
    overflow: hidden;
  }

  &__line {
    height: 8px;
    border-radius: 8px;
    transition: width 0.3s ease;
  }

  &__count {
    font-weight: 700;
    font-size: 16px;
    color: $dark-gray;
  }
}

@media (max-width: 768px) {
  .activities-card {
    min-height: 148px;
    padding: 16px;

    &__title {
      font-size: 16px;
    }

    &__name,
    &__count {
      font-size: 14px;
    }
  }
}
</style>
