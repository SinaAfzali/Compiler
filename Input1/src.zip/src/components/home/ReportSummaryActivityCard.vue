<template>
  <div class="card">
    <div v-if="title" class="card__content">
      <h3 class="title">{{ title }}</h3>

      <div v-if="activities && activities.length" class="activities-list">
        <div
          v-for="(item, index) in activities.slice(0, 3)"
          :key="index"
          class="activities-list__item"
        >
          <div class="activities-list__right">
            <span
              class="activities-list__status"
              :style="{ backgroundColor: item.color || 'green' }"
            ></span>
            <span class="activities-list__name">{{ item.name }}</span>
          </div>
          <span class="activities-list__date">{{ item.date }}</span>
        </div>
      </div>
    </div>

    <div v-else class="card__empty">
      <h3 class="title">خلاصه گزارش</h3>
      <p class="subtitle">اولین فعالیت خودت رو بساز.</p>
    </div>
  </div>
</template>

<script setup>
defineProps({
  title: { type: String, default: '' },
  number: { type: String, default: '' },
  activities: { type: Array },
})
</script>

<style lang="scss" scoped>
.card {
  width: 100%;
  box-sizing: border-box;
  height: 100%;
  @include flex(column, start, center);
  border-radius: 12px;
  background: white;
  padding: 20px 24px;

  &__content {
    width: 100%;
    @include flex(column, start, start);
  }

  &__empty {
    width: 100%;
    @include flex(column, center, center);
    flex: 1;
  }
}

.icon {
  width: 67px;
  height: 67px;
  margin-bottom: 12px;
}

.title {
  font-weight: 700;
  font-size: 18px;
  color: $dark-gray;
  margin: 0;
}

.subtitle {
  font-weight: 400;
  font-size: 16px;
  color: $light-gray;
  margin-top: 4px;
}

.activities-list {
  width: 100%;
  margin-top: 12px;
  @include flex(column, start, stretch, 8px);

  &__item {
    @include flex(row, space-between, center);

    .activities-list__date {
      font-size: 14px;
      color: $light-gray;
      text-align: left;
    }

    .activities-list__right {
      @include flex(row, start, center, 4px);

      .activities-list__name {
        font-size: 14px;
        color: $dark-gray;
        text-align: right;
      }

      .activities-list__status {
        width: 10px;
        height: 10px;
        border-radius: 50%;
      }
    }
  }
}

@media (max-width: 640px) {
  .icon {
    width: 36px;
    height: 36px;
  }

  .title {
    font-weight: 600;
    font-size: 14px;
  }

  .subtitle {
    font-size: 14px;
  }

  .activities-list__date,
  .activities-list__name {
    font-size: 12px;
  }
}
</style>
