<template>
  <div class="cards-container">
    <MoreActivityCard class="card card-1" number="1" />
    <ActivitiesRankCard class="card card-2" />
    <ReportSummaryActivityCard class="card card-3" />

    <!-- <MoreActivityCard
      class="card card-1"
      :title="moreCard.title"
      :subtitle="moreCard.subtitle"
      :number="moreCard.number"
    />
    <ActivitiesRankCard
      class="card card-2"
      :title="rankCard.title"
      :activities="rankCard.activities"
    />
    <ReportSummaryActivityCard
      class="card card-3"
      :title="summaryCard.title"
      :subtitle="summaryCard.subtitle"
      :activities="summaryCard.activities"
    /> -->
  </div>
</template>

<script setup>
import MoreActivityCard from './MoreActivityCard.vue'
import ActivitiesRankCard from './ActivitiesRankCard.vue'
import ReportSummaryActivityCard from './ReportSummaryActivityCard.vue'

// const moreCard = {
//   title: 'فعالیت بیشتر',
//   subtitle: 'جزئیات فعالیت‌ها',
//   number: '12',
// }

// const rankCard = {
//   title: 'رتبه‌بندی فعالیت‌ها',
//   activities: [
//     { name: 'دوچرخه‌سواری', count: 12 },
//     { name: 'پیاده‌روی', count: 8 },
//     { name: 'تمرین صبحگاهی', count: 5 },
//   ],
// }

// const summaryCard = {
//   title: 'خلاصه گزارش',
//   subtitle: 'فعالیت‌های اخیر',
//   activities: [
//     { name: 'دوچرخه‌سواری صبحگاهی', date: '21 مهر 1401', color: '#4AD66D' },
//     { name: 'تمرین جمعه', date: '22 مهر 1401', color: '#FFBF00' },
//     { name: 'مسیر طولانی', date: '23 مهر 1401', color: '#F7953B' },
//   ],
// }
</script>

<style lang="scss" scoped>
.cards-container {
  @include grid(calc(23% - 16px) 38% calc(33% - 16px), auto, 16px, center);
  width: 100%;
  min-height: 200px;
  box-sizing: border-box;

  .card {
    max-width: 100%;
    box-sizing: border-box;
  }
}

/* mini desk */
@media (max-width: 1360px) {
  .cards-container {
    @include grid(calc(48% - 16px) calc(48% - 16px), auto, 16px, center, center);
  }
}

/* Tablet */
@media (max-width: 1020px) {
  .cards-container {
    @include grid(80%, auto, 16px, center, center);
  }
}

/* Mobile */
@media (max-width: 640px) {
  .cards-container {
    @include grid(30% 60%, auto auto, 12px, center);
    grid-template-areas:
      'card1 card2'
      'card3 card3';

    .card-1 {
      grid-area: card1;
    }
    .card-2 {
      grid-area: card2;
    }
    .card-3 {
      grid-area: card3;
    }
  }
}
</style>
