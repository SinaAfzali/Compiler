<template>
  <div class="card">
    <IconComponent
      class="icon"
      :style="title !== '' ? 'fill: #2dc653;' : 'fill: #DADCE5'"
      :number="number"
    />
    <div v-if="title !== ''">
      <h3 class="title">{{ title }}</h3>
      <p class="subtitle">{{ subtitle }}</p>
    </div>
    <p v-else class="subtitle">بدون فعالیت</p>
  </div>
</template>

<script setup>
import IconComponent from '@/assets/icons/eight-pointed-star.vue'

defineProps({
  title: { type: String, default: '' },
  subtitle: { type: String, default: '' },
  number: { type: String, default: '' },
})
</script>

<style lang="scss" scoped>
.card {
  width: 100%;
  box-sizing: border-box;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border-radius: 12px;
  background: white;
}

.icon {
  width: 67px;
  height: 67px;
  margin-bottom: 12px;
  font-family: 'BYekanNum', serif;
}

.title {
  font-weight: 700;
  font-style: bold;
  font-size: 18px;
  line-height: 32px;
  letter-spacing: 0;
  color: $dark-gray;
  text-align: center;
  margin: 0;
}

.subtitle {
  font-weight: 400;
  font-style: normal;
  font-size: 16px;
  line-height: 32px;
  letter-spacing: 0;
  color: $light-gray;
  text-align: right;
  margin-top: 4px;
}

/* Mobile */
@media (max-width: 640px) {
  .icon {
    width: 36px;
    height: 36px;
  }

  .title {
    font-weight: 600;
    font-style: semibold;
    font-size: 14px;
    line-height: 24px;
    letter-spacing: 0;
  }

  .subtitle {
    font-size: 14px;
    line-height: 28px;
    letter-spacing: 0;
  }
}
</style>
