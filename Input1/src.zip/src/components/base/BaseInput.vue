<template>
  <div class="base-input" :class="wrapperClass" :style="wrapperStyle">
    <div class="base-input__wrapper">
      <span class="base-input__icon">
        <slot name="icon" />
      </span>

      <input
        :id="id"
        v-bind="field"
        :type="type"
        :class="[
          'base-input__input',
          inputClass,
          { 'base-input__input--raised': value },
          { 'base-input__input--error': errorMessage && value },
        ]"
        :style="inputStyle"
        :placeholder="placeholder"
        @input="$emit('input', $event)"
        @keydown="$emit('keydown', $event)"
      />

      <label
        v-if="label"
        :for="id"
        class="base-input__label"
        :class="{ 'base-input__label--active': value }"
      >
        {{ label }}
      </label>
    </div>

    <span v-if="errorMessage && value" class="base-input__error">
      {{ errorMessage }}
    </span>
  </div>
</template>

<script setup>
import { useField } from 'vee-validate'
import { computed } from 'vue'

const props = defineProps({
  name: { type: String, required: true },
  label: { type: String, default: '' },
  type: { type: String, default: 'text' },
  placeholder: { type: String, default: '' },
  rules: { type: [String, Object, Function], default: '' },
  wrapperClass: { type: [String, Array, Object], default: '' },
  inputClass: { type: [String, Array, Object], default: '' },
  wrapperStyle: { type: Object, default: () => ({}) },
  inputStyle: { type: Object, default: () => ({}) },

  id: {
    type: String,
    default: () => `input-${Math.random().toString(36).slice(2, 9)}`,
  },
})

const { value, errorMessage, handleBlur, handleChange } = useField(props.name, props.rules, {
  validateOnValueUpdate: true,
  validateOnSubmit: true,
})

const field = computed(() => ({
  value: value.value,
  onInput: handleChange,
  onBlur: handleBlur,
}))
</script>

<style lang="scss" scoped>
.base-input {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  width: 100%;

  &__wrapper {
    position: relative;
    width: 100%;
    box-sizing: border-box;
  }

  &__input {
    width: 100%;
    box-sizing: border-box;
    border: 1px solid #bec1ca;
    border-radius: 0.5rem;
    font-size: 1rem;
    font-family: 'BYekan', sans-serif;
    padding-right: 2.25rem;
    transition: border-color 0.2s;

    &:focus {
      outline: none;
      border-color: #464646;
    }

    &--raised {
      padding-top: 0.75rem;
    }

    &--error {
      border-color: red;
    }
    &--error:focus {
      border-color: red;
    }
  }

  &__label {
    position: absolute;
    top: 0.25rem;
    right: calc(0.75rem + 1.5rem);
    font-size: 12px;
    color: #464646;
    pointer-events: none;
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.2s ease;

    &--active {
      opacity: 1;
      transform: translateY(0);
    }
  }

  &__icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    display: flex;
    align-items: center;
    right: 0.5rem;
  }

  &__error {
    font-size: 0.75rem;
    color: red;
  }
}
</style>
