<template>
  <div class="base-password-input" :class="wrapperClass" :style="wrapperStyle">
    <label v-if="label" :for="id" class="base-password-input__label">{{ label }}</label>

    <div class="base-password-input__wrapper">
      <span
        class="base-password-input__icon base-password-input__icon--left"
        @click="toggleVisibility"
      >
        <slot v-if="!isVisible" name="eye-icon"></slot>
        <slot v-else name="eye-slash-icon"> </slot>
      </span>

      <span class="base-password-input__icon base-password-input__icon--right">
        <slot name="lock-icon"></slot>
      </span>

      <input
        :id="id"
        type="text"
        class="base-password-input__input"
        :class="[
          inputClass,
          {
            'base-password-input__input--star': !isVisible && password.length !== 0,
          },
          {
            'base-password-input__input--raised': isVisible && password.length !== 0,
          },
          { 'base-password-input__input--error': errorMessage && password },
        ]"
        :style="inputStyle"
        :value="isVisible ? password : passwordStar"
        @keydown="handleKeydown"
        @input="handleInput"
        :placeholder="placeholder"
      />

      <label
        v-if="label"
        :for="id"
        class="base-password-input__label"
        :class="{ 'base-password-input__label--active': password }"
      >
        {{ label }}
      </label>
    </div>

    <span v-if="errorMessage && password" class="base-password-input__error">{{
      errorMessage
    }}</span>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useField } from 'vee-validate'

const props = defineProps({
  name: { type: String, required: true },
  label: { type: String, default: '' },
  placeholder: { type: String, default: '' },
  rules: { type: [String, Object, Function], default: '' },
  inputClass: { type: [String, Object, Array], default: '' },
  wrapperClass: { type: [String, Object, Array], default: '' },
  inputStyle: { type: Object, default: () => ({}) },
  wrapperStyle: { type: Object, default: () => ({}) },
  hiddenChar: { type: String, default: '*' },

  id: {
    type: String,
    default: () => `pwd-${Math.random().toString(36).slice(2)}`,
  },
})

const isVisible = ref(false)
const password = ref('')
const passwordStar = ref('')

const { errorMessage, setValue } = useField(props.name, props.rules, {
  validateOnValueUpdate: true,
  validateOnSubmit: true,
})

const toggleVisibility = () => {
  isVisible.value = !isVisible.value
}

const handleKeydown = (e) => {
  const printable = e.key.length === 1 && !e.ctrlKey && !e.metaKey

  if (e.key === 'Backspace') {
    password.value = password.value.slice(0, -1)
    passwordStar.value = passwordStar.value.slice(0, -1)
  } else if (printable) {
    password.value += e.key
    passwordStar.value += props.hiddenChar
  }

  setValue(password.value)
  e.preventDefault()
}

const handleInput = (e) => {
  e.target.value = isVisible.value ? password.value : passwordStar.value
}
</script>

<style lang="scss" scoped>
.base-password-input {
  display: flex;
  flex-direction: column;
  position: relative;
  gap: 0.25rem;
  width: 100%;

  &__label {
    font-size: 0.875rem;
    font-weight: 500;
  }

  &__wrapper {
    position: relative;
    width: 100%;
  }

  &__input {
    width: 100%;
    min-height: 56px;
    box-sizing: border-box;
    padding: 0 2.25rem;
    border: 1px solid #bec1ca;
    border-radius: 0.5rem;
    font-size: 1rem;
    font-family: 'BYekan', sans-serif;
    line-height: 1.5rem;
    letter-spacing: 0.15em;

    &:focus {
      outline: none;
      border-color: #464646;
    }

    &--raised {
      padding-top: 0.75rem;
    }

    &--error {
      border-color: red;
    }
    &--error:focus {
      border-color: red;
    }
  }

  &__label {
    position: absolute;
    top: 0.25rem;
    right: calc(0.75rem + 1.5rem);
    font-size: 12px;
    color: #464646;
    pointer-events: none;
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.2s ease;
    z-index: 10000;

    &--active {
      opacity: 1;
      transform: translateY(0);
    }
  }

  &__input--star {
    padding-top: 1rem;
    font-size: 1.25rem;
    font-family: Arial, sans-serif;
  }

  &__icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    display: flex;
    align-items: center;
    cursor: pointer;

    &--left {
      left: 0.5rem;
    }

    &--right {
      right: 0.5rem;
      cursor: default;
    }
  }

  &__error {
    font-size: 0.75rem;
    color: #e11d48;
  }
}
</style>
