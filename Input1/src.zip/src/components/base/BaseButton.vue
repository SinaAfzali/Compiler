<template>
  <button
    :class="['base-button', buttonClass, variantClass]"
    :type="type"
    :disabled="disabled"
    @click="handleClick"
  >
    <slot name="content" />
  </button>
</template>

<script setup>
import { computed } from 'vue'

const emit = defineEmits(['click'])

const props = defineProps({
  type: { type: String, default: 'button' },
  variant: { type: String, default: 'default' },
  borderRadius: { type: String, default: '20px' },
  backgroundColor: { type: String, default: '#2471EB' },
  textColor: { type: String, default: '#FFF' },
  outlineColor: { type: String, default: '#2471EB' },
  disabled: { type: Boolean, default: false },
  buttonClass: { type: [String, Array, Object], default: '' },
})

const variantClass = computed(() =>
  props.variant === 'outline' ? 'base-button--outline' : 'base-button--default',
)

const handleClick = (event) => {
  if (!props.disabled) emit('click', event)
}
</script>

<style lang="scss" scoped>
$primary-color: #2471eb;
$white-color: #fff;
$disabled-opacity: 0.6;

.base-button {
  display: inline-flex;
  justify-content: center;
  align-items: center;
  padding: 0 16px;
  font-size: 16px;
  font-family: 'BYekan', sans-serif;
  cursor: pointer;
  transition: 0.2s ease all;
  width: 312px;
  height: 56px;
  border-radius: 20px;

  background-color: transparent;
  color: $primary-color;
  border: 1px solid $primary-color;

  /* Default state */
  &--default {
    background-color: $primary-color;
    color: $white-color;
    border: 1px solid transparent;
  }

  /* Outline state */
  &--outline {
    background-color: transparent;
    color: $primary-color;
    border: 1px solid $primary-color;

    &:hover {
      background-color: $primary-color;
      color: $white-color;
    }

    &:active {
      background-color: darken($primary-color, 10%);
      color: $white-color;
      border-color: darken($primary-color, 10%);
    }
  }

  /* Hover and active states for default button */
  &:hover {
    &.base-button--default {
      background-color: darken($primary-color, 10%);
    }

    &.base-button--outline {
      background-color: $primary-color;
      color: $white-color;
    }
  }

  &:active {
    &.base-button--default {
      background-color: darken($primary-color, 15%);
    }

    &.base-button--outline {
      background-color: darken($primary-color, 10%);
      border-color: darken($primary-color, 10%);
    }
  }

  &:disabled {
    cursor: not-allowed;
    opacity: $disabled-opacity;
  }

  @media (max-width: 768px) {
    height: 48px;
    font-size: 14px;
    border-radius: 16px;
  }
}
</style>
