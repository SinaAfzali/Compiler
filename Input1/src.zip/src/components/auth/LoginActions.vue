<template>
  <div class="auth-buttons">
    <span class="account-text">حساب کاربری ندارید؟</span>
    <router-link :to="{ name: 'register' }" class="signup-button"> ثبت نام </router-link>
  </div>
</template>

<script setup></script>

<style lang="scss" scoped>
.auth-buttons {
  display: flex;
  gap: 10px;
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
}

.account-text {
  font-size: 16px;
  line-height: 32px;
  color: #5a5a5a;
}

.signup-button {
  font-family: 'Yekan Bakh', sans-serif;
  font-weight: 600;
  font-size: 16px;
  line-height: 28px;
  color: #464646;
  text-decoration: none;
  cursor: pointer;
}

.signup-button:hover {
  color: #5a5a5a;
}
</style>
