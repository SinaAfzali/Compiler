<script setup>
import { Form } from 'vee-validate'
import ArrowRightIcon from '@/assets/icons/arrow-right.svg'
import { RouterLink } from 'vue-router'
defineProps({
  title: { type: String, required: true },
  hasArrowRight: { type: Boolean, default: false },
  backLink: { type: [String, Object], default: null },
})
</script>

<template>
  <div class="container">
    <div class="container__body">
      <RouterLink
        v-if="hasArrowRight"
        :to="backLink !== null ? backLink : { name: 'login' }"
        class="container__body__arrow-right"
      >
        <ArrowRightIcon />
      </RouterLink>
      <div class="container__body__bg">
        <img src="@/assets/images/AuthBG.png" alt="auth-bg" />
      </div>
      <div class="container__body__title">
        <div>{{ title }}</div>
      </div>
      <Form class="container__body__form">
        <slot name="top-input"></slot>
        <slot name="bottom-input"></slot>
        <slot name="submit-button"></slot>
        <slot name="extra-content"></slot>
      </Form>
    </div>
  </div>
</template>
<style lang="scss" scoped>
$shadow-color: #0043650d;

.container {
  min-height: 100vh;
  @include flex(column, center, center);

  &__body {
    @include flex(column);
    @include background('/src/assets/images/AuthPattern.svg', 30px);
    width: 532px;
    height: 732px;
    box-sizing: border-box;
    padding: 0;
    margin: 0;
    background-color: white;
    position: relative;
    border-radius: 24px;

    &__arrow-right {
      position: absolute;
      top: 36px;
      right: 36px;
    }
    &__bg {
      @include flex(row, center);
      box-sizing: border-box;

      img {
        width: 412px;
        height: 309px;
      }
    }

    &__title {
      font-size: 32px;
      font-weight: 700;
      line-height: 52px;
      color: $text-gray-dark;
      @include flex(row, center, center);
      margin-bottom: 16px;
    }

    &__form {
      background-color: white;
      @include flex(column, center, center, 28px);
    }
  }
}

@media (max-width: 768px) {
  .container {
    background-color: white;

    &__body {
      width: 304px;
      height: 676px;
      &__bg {
        img {
          width: 304px;
          height: 228px;
        }
      }
    }
  }
}
</style>
